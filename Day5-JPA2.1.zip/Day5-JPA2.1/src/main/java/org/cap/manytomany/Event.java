package org.cap.manytomany;

import java.util.ArrayList;
import java.util.List;

import javax.persistence.Entity;
import javax.persistence.Id;
import javax.persistence.JoinColumn;
import javax.persistence.JoinTable;
import javax.persistence.ManyToMany;

@Entity
public class Event {
	
	@Id
	private String eventid;
	private String event_name;
	
	@ManyToMany
	@JoinTable(name="event_delegate",
	joinColumns= {@JoinColumn(name="events")},
	inverseJoinColumns= {@JoinColumn(name="delegates")})
	private List<Delgates> delgates=new ArrayList<>();

	public Event() {
		
	}
	
	public Event(String event_id, String event_name) {
		super();
		this.eventid = event_id;
		this.event_name = event_name;
	}

	public String getEvent_id() {
		return eventid;
	}

	public void setEvent_id(String event_id) {
		this.eventid = event_id;
	}

	public String getEvent_name() {
		return event_name;
	}

	public void setEvent_name(String event_name) {
		this.event_name = event_name;
	}

	public List<Delgates> getDelgates() {
		return delgates;
	}

	public void setDelgates(List<Delgates> delgates) {
		this.delgates = delgates;
	}

	@Override
	public String toString() {
		return "Event [event_id=" + eventid + ", event_name=" + event_name + ", delgates=" + delgates + "]";
	}
	
	
	
}
