package org.cap.inheritance;


import javax.persistence.EntityManager;
import javax.persistence.EntityManagerFactory;
import javax.persistence.EntityTransaction;
import javax.persistence.Persistence;

public class TestInheritance {
	public static void main(String[] args) {


		EntityManagerFactory emf = 
				Persistence.createEntityManagerFactory("jpademo");
		EntityManager em = emf.createEntityManager();
		EntityTransaction transaction= em.getTransaction();

		transaction.begin();
		
		Project project=new Project(1001,"citibank");
		
		Module module=new Module();
		module.setProjectId(101);
		module.setProjectName("TransUnion");
		module.setModuleName("LoginModule");
		
		Task task=new Task();
		task.setProjectId(1009);
		task.setProjectName("Discover");
		task.setModuleName("Validation");
		task.setTaskName("Client side Validation");
		
		em.persist(project);
		em.persist(module);
		em.persist(task);
		
		transaction.commit();
		em.close();
	}
	
}
