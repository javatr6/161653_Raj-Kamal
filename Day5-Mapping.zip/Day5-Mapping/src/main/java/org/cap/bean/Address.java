package org.cap.bean;

import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.Id;
import javax.persistence.JoinColumn;
import javax.persistence.OneToOne;
import javax.persistence.Table;

@Entity
@Table(name="address")
public class Address {
	
	@Id
	@GeneratedValue
	private Integer address_id;
	private String address;
	@OneToOne
	@JoinColumn(name="customerfk")
	private Customer customer;
	
	public Address() {
		
	}
	
	public Address(String address) {
		super();
		this.address = address;
	}
	public Integer getAddress_id() {
		return address_id;
	}
	public void setAddress_id(Integer address_id) {
		this.address_id = address_id;
	}
	public String getAddress() {
		return address;
	}
	public void setAddress(String address) {
		this.address = address;
	}
	public Customer getCustomer() {
		return customer;
	}
	public void setCustomer(Customer customer) {
		this.customer = customer;
	}
	@Override
	public String toString() {
		return "Address [address_id=" + address_id + ", address=" + address + ", customer=" + customer + "]";
	}
	
	

}
