package org.cap.manytomany;

import java.util.ArrayList;
import java.util.List;

import javax.persistence.Entity;
import javax.persistence.Id;
import javax.persistence.JoinColumn;
import javax.persistence.JoinTable;
import javax.persistence.ManyToMany;

@Entity
public class Delgates {

	@Id
	private Integer delegate_id;
	private String name;
	
	@ManyToMany
	@JoinTable(name="event_delegate",
			joinColumns= {@JoinColumn(name="delegates")},
			inverseJoinColumns= {@JoinColumn(name="events")})
	private List<Event> events=new ArrayList<>();

	public Delgates() {
		
	}
	
	public Delgates(Integer delegate_id, String name) {
		super();
		this.delegate_id = delegate_id;
		this.name = name;
	}

	public Integer getDelegate_id() {
		return delegate_id;
	}

	public void setDelegate_id(Integer delegate_id) {
		this.delegate_id = delegate_id;
	}

	public String getName() {
		return name;
	}

	public void setName(String name) {
		this.name = name;
	}

	public List<Event> getEvents() {
		return events;
	}

	public void setEvents(List<Event> events) {
		this.events = events;
	}

	@Override
	public String toString() {
		return "Delgates [delegate_id=" + delegate_id + ", name=" + name + ", events=" + events + "]";
	}
	
	
}
