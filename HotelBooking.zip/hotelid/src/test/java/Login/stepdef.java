package Login;

import static org.junit.Assert.assertEquals;

import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.chrome.ChromeDriver;


import cucumber.api.java.Before;
import cucumber.api.java.en.Given;
import cucumber.api.java.en.Then;
import cucumber.api.java.en.When;

public class stepdef {
	private WebDriver webdriver;
	private WebElement webelement;
	@Before
	public void Setup() {
		System.setProperty("webdriver.chrome.driver","D:\\Users\\maddjs\\Downloads\\chrome driver\\chromedriver.exe"
				);
		webdriver=new ChromeDriver();
	}
	@Given("^for username and password$")
	public void for_username_and_password() throws Throwable {
		webdriver.get("file:///D:/madhu/hotelid/src/main/webapp/pages/login.html");
		String innertext=webdriver.findElement(By.xpath("//*[@id=\"mainCnt\"]/div/div[1]/h1")).getText();
		assertEquals(innertext,"Hotel Booking Application");
		 webdriver.findElement(By.name("userName")).sendKeys("Capgemini");
	    webdriver.findElement(By.name("userPwd")).sendKeys("capg1234");   
	}

	@When("^valid username and password$")
	public void valid_username_and_password() throws Throwable {
		WebElement webelement=webdriver.findElement(By.name("btn"));
		 webelement.submit();   
	}

	@Then("^navigate to hotelbooking page$")
	public void navigate_to_hotelbooking_page() throws Throwable {
		webdriver.navigate().to("file:///D:/madhu/hotelid/src/main/webapp/pages/hotelbooking.html");
	}
	@Given("^password$")
	public void password() throws Throwable {
		webdriver.get("file:///D:/madhu/hotelid/src/main/webapp/pages/login.html");
	    webdriver.findElement(By.name("userPwd")).sendKeys("capg1234");   
	}

	@When("^no username$")
	public void no_username() throws Throwable {
		WebElement webelement=webdriver.findElement(By.name("btn"));
		 webelement.click();  
	}

	@Then("^throws error message '\\* Please enter userName\\.'$")
	public void throws_error_message_Please_enter_userName() throws Throwable {
		String inner=webdriver.findElement(By.xpath("//*[@id=\"userErrMsg\"]")).getText();
		assertEquals(inner,"* Please enter userName.");
	}

	@Given("^username$")
	public void username() throws Throwable {
		webdriver.get("file:///D:/madhu/hotelid/src/main/webapp/pages/login.html");
		 webdriver.findElement(By.name("userName")).sendKeys("Capgemini");
	}

	@When("^no password$")
	public void no_password() throws Throwable {
		WebElement webelement=webdriver.findElement(By.name("btn"));
		 webelement.click();
	}

	@Then("^throws error message '\\* Please enter password\\.'$")
	public void throws_error_message_Please_enter_password() throws Throwable {
		String text=webdriver.findElement(By.xpath("//*[@id=\"pwdErrMsg\"]")).getText();
		assertEquals(text,"* Please enter password.");
	}




}
