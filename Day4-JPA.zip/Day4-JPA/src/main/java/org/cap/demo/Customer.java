package org.cap.demo;

import java.util.Date;

import javax.persistence.Entity;
import javax.persistence.Id;

@Entity
public class Customer {
	
	@Id
	private String customerId;
	private String customerName;
	private String regfees;
	private Date date;

	public Customer() {

	}

	public String getCustomerId() {
		return customerId;
	}

	public void setCustomerId(String customerId) {
		this.customerId = customerId;
	}

	public String getCustomerName() {
		return customerName;
	}

	public void setCustomerName(String customerName) {
		this.customerName = customerName;
	}

	public String getRegfees() {
		return regfees;
	}

	public void setRegfees(String regfees) {
		this.regfees = regfees;
	}

	public Date getDate() {
		return date;
	}

	public void setDate(Date date) {
		this.date = date;
	}

	@Override
	public String toString() {
		return "Customer [customerId=" + customerId + ", customerName=" + customerName + ", regfees=" + regfees
				+ ", date=" + date + "]";
	}

	public Customer(String customerId, String customerName, String regfees, Date date) {
		super();
		this.customerId = customerId;
		this.customerName = customerName;
		this.regfees = regfees;
		this.date = date;
	}

}
